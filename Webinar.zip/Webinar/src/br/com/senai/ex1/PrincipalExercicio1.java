package br.com.senai.ex1;

public class PrincipalExercicio1 {

	public static void main(String[] args) {
		
		Alunos aluno = new Alunos();

		aluno.setNota1(7);
		aluno.setNota2(8);
		
		aluno.media(); 
	}

}
